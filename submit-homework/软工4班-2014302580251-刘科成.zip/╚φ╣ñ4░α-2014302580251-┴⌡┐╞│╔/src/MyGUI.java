import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class MyGUI extends JFrame{
	public JButton button1;
	public JButton button2;
	public JButton button3;
	public JButton button4;
	public JButton button5;
	public JButton button6;
	public JButton button7;
	public JButton button8;
	public JButton button9;
	public JButton button10;
	public JButton button11;
	public JButton button12;
	
	public MyGUI(){
		super("Pet Shop");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(600,400);
		setVisible(true);
		
		JPanel panel= new JPanel();
		add(panel);
		panel.setLayout(null);
		PetReader pr=new PetReader();
		ArrayList<Pet> shoppingCart=new ArrayList();
		
		JButton introduction=new JButton("������水ť�Լ��빺�ﳵ");
		panel.add(introduction);
		introduction.setBounds(60,10,500,30);
		
		JButton button1=new JButton("dog");
		panel.add(button1);
		button1.setBounds(60,50,100,50);
		button1.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						shoppingCart.add(pr.list.get(0));
					}
				}
			);
		
		JButton button2=new JButton("cat");
		panel.add(button2);
		button2.setBounds(180,50,100,50);
		button2.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						shoppingCart.add(pr.list.get(1));
					}
				}
			);

		JButton button3=new JButton("turtle");
		panel.add(button3);
		button3.setBounds(300,50,100,50);
		button3.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						shoppingCart.add(pr.list.get(2));
					}
				}
			);

		JButton button4=new JButton("parrot");
		panel.add(button4);
		button4.setBounds(420,50,100,50);
		button4.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						shoppingCart.add(pr.list.get(3));
					}
				}
			);

		JButton button5=new JButton("hamster");
		panel.add(button5);
		button5.setBounds(60,125,100,50);
		button5.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						shoppingCart.add(pr.list.get(4));
					}
				}
			);

		JButton button6=new JButton("squirrel");
		panel.add(button6);
		button6.setBounds(180,125,100,50);
		button6.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						shoppingCart.add(pr.list.get(5));
					}
				}
			);
		
		JButton button7=new JButton("rabbit");
		panel.add(button7);
		button7.setBounds(300,125,100,50);
		button7.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						shoppingCart.add(pr.list.get(6));
					}
				}
			);
		
		JButton button8=new JButton("snake");
		panel.add(button8);
		button8.setBounds(420,125,100,50);
		button8.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						shoppingCart.add(pr.list.get(7));
					}
				}
			);
		
		JButton button9=new JButton("lizard");
		panel.add(button9);
		button9.setBounds(60,200,100,50);
		button9.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						shoppingCart.add(pr.list.get(8));
					}
				}
			);
		
		JButton button10=new JButton("fish");
		panel.add(button10);
		button10.setBounds(180,200,100,50);
		button10.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						shoppingCart.add(pr.list.get(9));
					}
				}
			);
		
		JButton button11=new JButton("myna");
		panel.add(button11);
		button11.setBounds(300,200,100,50);
		button11.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						shoppingCart.add(pr.list.get(10));
					}
				}
			);
		
		JButton button12=new JButton("canary");
		panel.add(button12);
		button12.setBounds(420,200,100,50);
		button12.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						shoppingCart.add(pr.list.get(11));
					}
				}
			);
		
		JButton show=new JButton("��ʾ���ﳵ�еı���");
		panel.add(show);
		show.setBounds(60,275,400,50);
		show.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						String string="";
						for(int i=0;i<shoppingCart.size();i++){
							string+=shoppingCart.get(i).getName();
							string+=" ";
						}
						JOptionPane.showMessageDialog(MyGUI.this,String.format(string));
					}
				}
			);
	}

}
