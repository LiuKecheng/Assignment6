import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class PetReader {
	public ArrayList<Pet> list;
	public PetReader(){this.list=read();}
	
	public static ArrayList<Pet> read(){
	ArrayList<Pet> list=new ArrayList();

	String className="com.mysql.jdbc.Driver";
	String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	String userName="root";
	String userPassword="123456";
	String tableName="pet";
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	try{
	Class.forName(className);
	con=DriverManager.getConnection(url, userName, userPassword);
	ps=con.prepareStatement("select * FROM "+tableName);
	rs=ps.executeQuery();
	while(rs.next())
	{
		Pet pet=new Pet();
		for(int i=0;i<rs.getMetaData().getColumnCount();++i){
			if(i==0)
				pet.setID(Integer.valueOf(rs.getString(i+1)));
			if(i==1)
				pet.setName(rs.getString(i+1));
			if(i==2)
				pet.setEat(rs.getString(i+1));
			if(i==3)
				pet.setDrink(rs.getString(i+1));
			if(i==4)
				pet.setLive(rs.getString(i+1));
			if(i==5)
				pet.setHobby(rs.getString(i+1));
		}
		list.add(pet);
		System.out.println();
	}
	}catch(Exception e){
		System.out.println(e.toString());
	}finally{
		try{rs.close();}catch(Exception e){}
		try{con.close();}catch(Exception e){}
	}
	return list;
	}

}
